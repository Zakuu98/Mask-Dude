import greenfoot.*;

public class ButtonInfo extends Actor
{
    public ButtonInfo() {
    GreenfootImage img = new GreenfootImage("Button/ButtonInfo.png");
    img.scale(50, 50); // ubah ukuran lebar dan tinggi (pixel)
    setImage(img);
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new InfoWorld()); // Ganti ke Level1
        }
    }
}
