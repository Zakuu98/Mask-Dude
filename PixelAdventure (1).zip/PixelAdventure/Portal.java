import greenfoot.*;

public class Portal extends Actor {
    private boolean isActive = false;
    private GreenfootImage[] portalFrames;
    private int frameIndex = 0;
    private int animationDelay = 5;
    private int animationCounter = 0;

    public Portal() {
        loadFrames();
        setImage(portalFrames[0]); // tampilkan frame awal
    }

    private void loadFrames() {
        portalFrames = new GreenfootImage[3]; // misal 6 frame
        for (int i = 0; i < portalFrames.length; i++) {
            portalFrames[i] = new GreenfootImage("Portal/Dimensional_Portal1_" + i + ".png");
        }
    }

    public void act() {
        animatePortal(); // Jalankan animasi setiap frame

        Player player = (Player) getOneIntersectingObject(Player.class);
        if (player == null) return;

        // 🔹 Portal2 aktif setelah 3 apel
        if (!isActive && player.getApplesCollected() >= 50) { //harus 6 apple
            isActive = true;
            // System.out.println("Portal2 aktif! Kamu bisa masuk ke level berikutnya.");
        }

        // 🔹 Jika portal aktif dan disentuh pemain → pindah ke Level2
        if (isActive && isTouching(Player.class)) {
            Greenfoot.setWorld(new Level2());
            player.applesCollected = 0;
        }
    }

    private void animatePortal() {
        if (portalFrames == null || portalFrames.length == 0) return; // ⛔ cegah error
        animationCounter++;
        if (animationCounter >= animationDelay) {
            frameIndex = (frameIndex + 1) % portalFrames.length;
            setImage(portalFrames[frameIndex]);
            animationCounter = 0;
        }
    }
}
