import greenfoot.*;  
import java.util.Random;

/**
 * Kelas MyWorld merupakan world utama dalam game platformer.
 * Menampilkan background dan akan menampung objek seperti player, enemy, dan platform.
 */
public class Trophy_Room extends World
{
    // Ukuran world dan skala tile
    public static final int WORLD_WIDTH = 800;
    public static final int WORLD_HEIGHT = 600;
    public static final int CELL_SIZE = 1; // 1 pixel per cell agar background tajam

    /**
     * Constructor untuk objek MyWorld.
     */
    
    
    public Trophy_Room()
    {    
        super(WORLD_WIDTH, WORLD_HEIGHT, CELL_SIZE, false);
        prepareWorld();
        SoundManager sound = new SoundManager();
        sound.initBgm("MenuMusic.mp3",50);
        sound.playBgm();
    }
    
    /**
     * Method untuk menyiapkan elemen awal di world.
     */
    private void prepareWorld()
    {
        // Atur background

        setLayeredBackground();
        // Tambahkan player di tengah bawah lembah
        Player player = new Player();
        addObject(new Player(), 15,536);
        
        FontText title = new FontText("TROPHY ROOM", 48, Color.WHITE);
        addObject(title, getWidth() / 2, 30);
        
        addObject(new Batu_Bata_Abu_Kecil(), 316, 548);
        addObject(new Batu_Bata_Abu_Kecil(), 457, 548);
        addObject(new Kubus_Besi(), 329, 544);
        addObject(new Kubus_Besi(), 329, 384);
        addObject(new Kubus_Besi(), 445, 544);
        addObject(new Kubus_Besi(), 445, 382);
        addObject(new Batu_Bata_Abu_Stand(), 341, 546);
        addObject(new Batu_Bata_Abu_Stand(), 356, 528);
        addObject(new Batu_Bata_Abu_Stand(), 418, 528);
        addObject(new Batu_Bata_Abu_Stand(), 432, 543);
        addObject(new Batu_Bata_Abu(), 387, 547);
        addObject(new Batu_Bata_Abu_Kotak(), 388, 516);
        
        addObject(new Balok_Besi(), 760, 8);
        addObject(new Balok_Besi(), 40, 8);
        addObject(new Balok_Besi(), 712, 8);
        addObject(new Balok_Besi(), 88, 8);
        addObject(new Balok_Besi_Stand(), 792, 40);
        addObject(new Balok_Besi_Stand(), 8, 40);
        addObject(new Balok_Besi_Stand(), 792, 88);
        addObject(new Balok_Besi_Stand(), 8, 88);
        addObject(new Kubus_Besi(), 792, 8);
        addObject(new Kubus_Besi(), 8, 8);
        addObject(new Kubus_Besi(), 776, 24);
        addObject(new Kubus_Besi(), 24, 24);
        addObject(new Balok_Besi(), 744, 24);
        addObject(new Balok_Besi(), 56, 24);
        addObject(new Balok_Besi_Stand(), 776, 56);
        addObject(new Balok_Besi_Stand(), 24, 56);
        
        addObject(new Bendera_Besar(), 739, 51);
        addObject(new Bendera_Besar(), 57, 51);
        addObject(new Bendera_Besar(), 326,412);
        addObject(new Bendera_Besar(), 446,412);
        addObject(new Trophy(), 388,464);

        // Generate platform (tanah dasar + tebing kiri kanan)
        generatePlatforms();
    }
private void setLayeredBackground() {
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.BLACK);
        bg.fill();
        setBackground(bg);
    }
    /**
     * Membuat platform tanah penuh & tebing kiri–kanan berbentuk upside-down (piramid terbalik rendah).
     */
    private void generatePlatforms()
{
    Batu_Bata_Abu_Kotak sample = new Batu_Bata_Abu_Kotak();
    int tileWidth = sample.getImage().getWidth();
    int tileHeight = sample.getImage().getHeight();

    // 1️⃣ Tanah dasar penuh (lembah bawah)
    for (int x = 0; x < WORLD_WIDTH; x += tileWidth) {
        addObject(new Batu_Bata_Abu_Kotak(), x + tileWidth / 2, WORLD_HEIGHT - tileHeight / 2);
    }
}
}
