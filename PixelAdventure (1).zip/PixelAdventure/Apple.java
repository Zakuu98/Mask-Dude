import greenfoot.*;

public class Apple extends Actor {
    private GreenfootImage[] idleFrames;
    private GreenfootImage[] collectedFrames;
    private int frame = 0;
    private int animationDelay = 5;
    private int delayCounter = 0;
    private boolean collected = false;

    public Apple() {
        idleFrames = new GreenfootImage[17];
        for (int i = 0; i < 17; i++) {
            idleFrames[i] = new GreenfootImage("Level1/Items/Apple/" + String.format("%02d_Apple.png", i));
        }

        collectedFrames = new GreenfootImage[6];
        for (int i = 0; i < 6; i++) {
            collectedFrames[i] = new GreenfootImage("Level1/Items/Collected/" + String.format("%02d_Collected.png", i));
        }

        setImage(idleFrames[0]);
    }

    public void act() {
        animate();
          
    }

    private void animate() {
        delayCounter++;
        if (delayCounter >= animationDelay) {
            delayCounter = 0;

            if (!collected) {
                frame = (frame + 1) % idleFrames.length;
                setImage(idleFrames[frame]);
            } else {
                if (frame < collectedFrames.length - 1) {
                    frame++;
                    setImage(collectedFrames[frame]);
                } else {
                    getWorld().removeObject(this); // hapus SETELAH animasi selesai
                }
            }
        }
    }

    public void collect() {
        if (!collected) {
            collected = true;
            frame = 0;
        }
    }
}
