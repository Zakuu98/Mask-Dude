import greenfoot.*;

public class Portal2 extends Actor {
    private boolean isActive = false; // Portal2 terkunci dulu
    private GreenfootImage[] portalFrames; // Menyimpan gambar animasi
    private int frameIndex = 0; 
    private int animationDelay = 5; 
    private int animationCounter = 0;

    public Portal2() {
        // 🔹 Memuat gambar dari folder "Portal2"
        int totalFrames = 8; // jumlah frame yang kamu punya (ubah sesuai jumlah file)
        portalFrames = new GreenfootImage[totalFrames];

        for (int i = 0; i < portalFrames.length; i++) {
            portalFrames[i] = new GreenfootImage("Portal2/PORTAL" + i + ".png");
        }

        setImage(portalFrames[0]); // gambar awal
    }

    public void act() {
        animatePortal(); // Jalankan animasi setiap frame

        Player player = (Player) getOneIntersectingObject(Player.class);
        if (player == null) return;

        // 🔹 Portal2 aktif setelah 3 apel
        if (!isActive && player.getApplesCollected() >= 100) { //harus 6 apple
            isActive = true;
            // System.out.println("Portal2 aktif! Kamu bisa masuk ke level berikutnya.");
        }

        // 🔹 Jika portal aktif dan disentuh pemain → pindah ke Level2
        if (isActive && isTouching(Player.class)) {
            Greenfoot.setWorld(new Level3());
            player.applesCollected = 0;
        }
    }

    // 🔹 Fungsi animasi portal
    private void animatePortal() {
        animationCounter++;
        if (animationCounter % animationDelay == 0) {
            frameIndex = (frameIndex + 1) % portalFrames.length;
            setImage(portalFrames[frameIndex]);
        }
    }
}
