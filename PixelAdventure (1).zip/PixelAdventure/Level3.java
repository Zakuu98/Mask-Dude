import greenfoot.*;  
import java.util.Random;

/**
 * Kelas MyWorld merupakan world utama dalam game platformer.
 * Menampilkan background dan akan menampung objek seperti player, enemy, dan platform.
 */
public class Level3 extends World
{
    // Ukuran world dan skala tile
    public static final int WORLD_WIDTH = 800;
    public static final int WORLD_HEIGHT = 600;
    public static final int CELL_SIZE = 1; // 1 pixel per cell agar background tajam

    /**
     * Constructor untuk objek MyWorld.
     */
    
    
    public Level3()
    {    
        super(WORLD_WIDTH, WORLD_HEIGHT, CELL_SIZE, false);
        prepareWorld();
        addObject(new Portal_Trophy(), 386, 518);
        
        SoundManager sound = new SoundManager();
        sound.initBgm("Backsound.mp3",50);
        sound.playBgm();
        
        FontText title = new FontText("LEVEL 3", 48, Color.WHITE);
        addObject(title, getWidth() / 2, 30);
    }
    
    /**
     * Method untuk menyiapkan elemen awal di world.
     */
    private void prepareWorld()
    {
        // Atur background

        setLayeredBackground();
        // Tambahkan player di tengah bawah lembah
        Player player = new Player();
        addObject(new Player(), 386, 346);
        
        addObject(new Batu_Bata_Abu(), 386, 538);
        addObject(new Batu_Bata_Abu(), 360, 547);
        addObject(new Batu_Bata_Abu(), 409, 547);
        addObject(new Batu_Bata_Abu(), 386, 366);
        
        addObject(new Kubus_Besi(), 441,305);
        addObject(new Kubus_Besi(), 340,252);
        addObject(new Kubus_Besi(), 432,193);
        addObject(new Apple(), 388,109);
        
        addObject(new Balok_Besi(), 536, 272);
        addObject(new Batu_Bata_Abu(), 583, 268);
        addObject(new Batu_Bata_Abu(), 631, 268);
        addObject(new Batu_Bata_Abu(), 640, 174);
        addObject(new Batu_Bata_Abu_Stand(), 659, 249);
        addObject(new Batu_Bata_Abu_Stand(), 659, 202);
        addObject(new Batu_Bata_Abu_Stand(), 563, 194);
        addObject(new Batu_Bata_Abu(), 591, 174);
        addObject(new Batu_Bata_Abu(), 583, 222);
        addObject(new Apple(), 584, 203);
        
        addObject(new Batu_Bata_Abu_Stand(), 274, 201);
        addObject(new Batu_Bata_Abu_Stand(), 209, 135);
        addObject(new Batu_Bata_Abu_Stand(), 133, 211);
        addObject(new Batu_Bata_Abu_Stand(), 51, 268);
        addObject(new Apple(), 51, 231);
        
        addObject(new Batu_Bata_Abu(), 227, 403);
        addObject(new Batu_Bata_Abu(), 179, 403);
        addObject(new Batu_Bata_Abu(), 131, 403);
        addObject(new Batu_Bata_Abu(), 83, 403);
        addObject(new Batu_Bata_Abu(), 35, 403);
        addObject(new Batu_Bata_Abu(), 39, 319);
        addObject(new Batu_Bata_Abu_Stand(), 67, 339);
        addObject(new Balok_Besi(), 275, 407);
        addObject(new Balok_Besi_Stand(), 7, 385);
        addObject(new Balok_Besi_Stand(), 7, 339);
        addObject(new Spike(), 63, 307);
        addObject(new Spike(), 39, 307);
        addObject(new Spike(), 15, 307);
        addObject(new Apple(), 40, 344);
        addObject(new Enemy(), 159, 383);
        
        addObject(new Batu_Bata_Abu(), 500, 340);
        addObject(new Batu_Bata_Abu(), 550, 377);
        addObject(new Batu_Bata_Abu(), 614, 365);
        addObject(new Batu_Bata_Abu(), 669, 383);
        addObject(new Batu_Bata_Abu(), 719, 370);
        addObject(new Batu_Bata_Abu(), 780, 354);
        addObject(new Balok_Besi_Stand(), 748, 336);
        addObject(new Spike(), 551, 365);
        addObject(new Spike(), 613, 353);
        addObject(new Spike(), 670, 372);
        addObject(new Spike(), 720, 358);
        addObject(new Spike(), 780, 343);
        addObject(new Kubus_Besi(), 582,344);
        addObject(new Kubus_Besi(), 641,336);
        addObject(new Kubus_Besi(), 696,343);
        addObject(new Apple(), 748, 299);
        
        addObject(new Kubus_Besi(), 520,544);
        addObject(new Kubus_Besi(), 739,544);
        addObject(new Batu_Bata_Abu_Kotak(), 553, 528);
        addObject(new Batu_Bata_Abu_Kotak(), 706, 528);
        addObject(new Enemy(), 636, 534);
        addObject(new Apple(), 772, 534);
        
        addObject(new Kubus_Besi(), 335,474);
        addObject(new Kubus_Besi(), 448,480);
        addObject(new Balok_Besi_Stand(), 144, 513);
        addObject(new Balok_Besi(), 144, 544);
        addObject(new Spike(), 178, 544);
        addObject(new Spike(), 160, 528);
        addObject(new Spike(), 132, 528);
        addObject(new Spike(), 115, 544);
        addObject(new Apple(), 23, 535);
        
        addObject(new Balok_Besi(), 760, 8);
        addObject(new Balok_Besi(), 40, 8);
        addObject(new Balok_Besi(), 712, 8);
        addObject(new Balok_Besi(), 88, 8);
        addObject(new Balok_Besi_Stand(), 792, 40);
        addObject(new Balok_Besi_Stand(), 8, 40);
        addObject(new Balok_Besi_Stand(), 792, 88);
        addObject(new Balok_Besi_Stand(), 8, 88);
        addObject(new Kubus_Besi(), 792, 8);
        addObject(new Kubus_Besi(), 8, 8);
        addObject(new Kubus_Besi(), 776, 24);
        addObject(new Kubus_Besi(), 24, 24);
        addObject(new Balok_Besi(), 744, 24);
        addObject(new Balok_Besi(), 56, 24);
        addObject(new Balok_Besi_Stand(), 776, 56);
        addObject(new Balok_Besi_Stand(), 24, 56);
        
        addObject(new Bendera_Kecil(), 334, 481);
        addObject(new Bendera_Kecil(), 448, 488);
        addObject(new Bendera_Kecil(), 582, 351);
        addObject(new Bendera_Kecil(), 641, 344);
        addObject(new Bendera_Kecil(), 696, 351);
        addObject(new Bendera_Kecil(), 440, 312);
        addObject(new Bendera_Kecil(), 340, 258);
        addObject(new Bendera_Kecil(), 432, 200);
        addObject(new Bendera_Besar(), 386, 393);
        addObject(new Bendera_Besar(), 739, 51);
        addObject(new Bendera_Besar(), 57, 51);
        
        
        
        
        // Generate platform (tanah dasar + tebing kiri kanan)
        generatePlatforms();
    }
private void setLayeredBackground() {
        // Pastikan semua file ada di folder "Background/"
        String[] layerFiles = {
            "Background/1.png", // paling belakang
            "Background/2.png",
            "Background/3.png",
            "Background/4.png",
            "Background/5.png",
            "Background/6.png"// paling depan
        };

        // Gunakan ukuran world sebagai dasar
        GreenfootImage finalBg = new GreenfootImage(WORLD_WIDTH, WORLD_HEIGHT);

        for (String file : layerFiles) {
            GreenfootImage layer = new GreenfootImage(file);
            
            // Sesuaikan ukuran layer agar cocok dengan ukuran world
            layer.scale(WORLD_WIDTH, WORLD_HEIGHT);
            
            // Gabungkan layer satu per satu (belakang ke depan)
            finalBg.drawImage(layer, 0, 0);
        }

        setBackground(finalBg);
    }
    /**
     * Membuat platform tanah penuh & tebing kiri–kanan berbentuk upside-down (piramid terbalik rendah).
     */
    private void generatePlatforms()
{
    Batu_Bata_Abu_Kotak sample = new Batu_Bata_Abu_Kotak();
    int tileWidth = sample.getImage().getWidth();
    int tileHeight = sample.getImage().getHeight();

    // 1️⃣ Tanah dasar penuh (lembah bawah)
    for (int x = 0; x < WORLD_WIDTH; x += tileWidth) {
        addObject(new Batu_Bata_Abu_Kotak(), x + tileWidth / 2, WORLD_HEIGHT - tileHeight / 2);
    }
}
}
