import greenfoot.*;

/**
 * Kelas Level1 — menampilkan background berlapis dan menambahkan objek.
 */
public class Level1 extends World {
    public static final int WORLD_WIDTH = 800;
    public static final int WORLD_HEIGHT = 600;
    public static final int CELL_SIZE = 1;
    
    
      private boolean gameOverShown = false;
    
    public Level1() {
        super(WORLD_WIDTH, WORLD_HEIGHT, CELL_SIZE, false);
        setLayeredBackground();
        prepareWorld();
        
        SoundManager sound = new SoundManager();
        sound.initBgm("Backsound.mp3",50);
        sound.playBgm();
        
        // PRELOAD efek apple/coin supaya tidak delay saat koleksi pertama
        SoundManager.preloadEffect("applecollected.mp3", 80); // ganti nama file sesuai milikmu
        // jika ada efek lain: preload juga
        SoundManager.preloadEffect("hit.mp3", 80);
        //addObject(new Portal(), 782, 231);
        
        //FontText title = new FontText("LEVEL 1", 48, Color.WHITE);
        //addObject(title, getWidth() / 2, 30);
    }

    /**
     * Menyusun background menjadi beberapa lapisan: 01 (paling belakang) → 04 (paling depan)
     */
    private void setLayeredBackground() {
        // Pastikan semua file ada di folder "Background/"
        String[] layerFiles = {
            "Background/01.png", // paling belakang
            "Background/02.png",
            "Background/03.png",
            "Background/04.png"  // paling depan
        };

        // Gunakan ukuran world sebagai dasar
        GreenfootImage finalBg = new GreenfootImage(WORLD_WIDTH, WORLD_HEIGHT);

        for (String file : layerFiles) {
            GreenfootImage layer = new GreenfootImage(file);
            
            // Sesuaikan ukuran layer agar cocok dengan ukuran world
            layer.scale(WORLD_WIDTH, WORLD_HEIGHT);
            
            // Gabungkan layer satu per satu (belakang ke depan)
            finalBg.drawImage(layer, 0, 0);
        }

        setBackground(finalBg);
    }

    /**
     * Menambahkan objek dalam world.
     */
    private void prepareWorld() {
        addObject(new Portal(), 782, 231);
        
        FontText title = new FontText("LEVEL 1", 48, Color.WHITE);
        addObject(title, getWidth() / 2, 30);
        
        
        Player player = new Player();
        addObject(player, WORLD_WIDTH / 10, 540);

        addObject(new Batu_Bata_Abu(), 524, 351);
        addObject(new Batu_Bata_Abu(), 364, 336);
        addObject(new Batu_Bata_Abu(), 200, 272);
        addObject(new Batu_Bata_Abu(), 152, 272);
        addObject(new Batu_Bata_Abu(), 104, 272);
        addObject(new Batu_Bata_Abu(), 56, 272);
        addObject(new Batu_Bata_Abu(), 8, 272);
        addObject(new Batu_Bata_Abu_Kecil(), 35, 554);
        addObject(new Batu_Bata_Abu_Kecil(), 20, 536);
        addObject(new Batu_Bata_Abu_Kecil(), 21, 508);
        addObject(new Batu_Bata_Abu_Kecil(), 12, 508);
        addObject(new Kubus_Kayu(), 24, 548);
        addObject(new Balok_Kayu_Stand(), 8, 532);
        addObject(new Balok_Kayu(), 23, 563);
        addObject(new Batu_Bata_Abu_Kotak(), 450, 345);
        addObject(new Spike(), 438, 315);
        addObject(new Spike(), 464, 315);
        addObject(new Apple(), 524, 334);
        addObject(new Apple(), 364, 319);
        addObject(new Apple(), 30, 255);
        addObject(new Kubus_Kayu(), 282, 306);
        addObject(new Kubus_Kayu(), 451, 289);

        addObject(new Balok_Kayu(), 760, 8);
        addObject(new Balok_Kayu(), 40, 8);
        addObject(new Balok_Kayu(), 712, 8);
        addObject(new Balok_Kayu(), 88, 8);
        addObject(new Balok_Kayu_Stand(), 792, 40);
        addObject(new Balok_Kayu_Stand(), 8, 40);
        addObject(new Balok_Kayu_Stand(), 792, 88);
        addObject(new Balok_Kayu_Stand(), 8, 88);
        addObject(new Kubus_Kayu(), 792, 8);
        addObject(new Kubus_Kayu(), 8, 8);
        addObject(new Kubus_Kayu(), 776, 24);
        addObject(new Kubus_Kayu(), 24, 24);
        addObject(new Balok_Kayu(), 744, 24);
        addObject(new Balok_Kayu(), 56, 24);
        addObject(new Balok_Kayu_Stand(), 776, 56);
        addObject(new Balok_Kayu_Stand(), 24, 56);
        addObject(new Enemy(), 207, 538);
        addObject(new Enemy(), 138, 252);
        
        addObject(new Mineral_Biru(), 456, 353);
        addObject(new Mineral_Biru(), 532, 525);
        addObject(new Mineral_Biru(), 15, 547);
        addObject(new Bendera_Besar(), 739, 51);
        addObject(new Bendera_Besar(), 57, 51);
        addObject(new Bendera_Besar(), 363, 366);
        addObject(new Bendera_Kecil(), 523, 360);
        

        generatePlatforms();
    }

    private void generatePlatforms() {
        RumputHijauu sample = new RumputHijauu();
        int tileWidth = sample.getImage().getWidth();
        int tileHeight = sample.getImage().getHeight();

        for (int x = 0; x < WORLD_WIDTH; x += tileWidth) {
            addObject(new RumputHijauu(), x + tileWidth / 2, WORLD_HEIGHT - tileHeight / 2);
        }

        int layers = 7;
        int baseY = WORLD_HEIGHT - tileHeight;

        for (int i = 0; i < layers; i++) {
            int blocks = layers - i;
            int y = baseY - i * tileHeight;
            for (int j = 0; j < blocks; j++) {
                int x = WORLD_WIDTH - (tileWidth / 2 + j * tileWidth);
                addObject(new RumputHijauu(), x, y);
            }
        }
    }
    
     public void act()
    {
        // Cek apakah GameOver sudah muncul
        if (!getObjects(GameOver.class).isEmpty()) {
            gameOverShown = true;
        }

        // Jika Enter ditekan saat GameOver muncul, restart game
        if (gameOverShown && Greenfoot.isKeyDown("enter")) {
            Greenfoot.setWorld(new Level1());
        }
    }
}
