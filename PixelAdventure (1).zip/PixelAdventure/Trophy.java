import greenfoot.*;

public class Trophy extends Actor
{
    public Trophy() {
    GreenfootImage img = new GreenfootImage("Trophy.png");
    img.scale(80, 80); // ubah ukuran lebar dan tinggi (pixel)
    setImage(img);
    }
}
