import greenfoot.*;

public class ButtonMenu extends Actor
{
    public ButtonMenu() {
        GreenfootImage img = new GreenfootImage("Button/Previous.png");
        img.scale(100, 100);
        setImage(img);
    }

    public void act() {
        if (Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown("enter")) {
            BackMenu();
        }
    }

    private void BackMenu() {
        Greenfoot.setWorld(new MainMenu());
        Greenfoot.start(); // pastikan simulasi berjalan kembali
    }
}
