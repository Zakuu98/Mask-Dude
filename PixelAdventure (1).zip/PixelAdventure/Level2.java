import greenfoot.*;  
import java.util.Random;

/**
 * Kelas MyWorld merupakan world utama dalam game platformer.
 * Menampilkan background dan akan menampung objek seperti player, enemy, dan platform.
 */
public class Level2 extends World
{
    // Ukuran world dan skala tile
    public static final int WORLD_WIDTH = 800;
    public static final int WORLD_HEIGHT = 600;
    public static final int CELL_SIZE = 1; // 1 pixel per cell agar background tajam

    /**
     * Constructor untuk objek MyWorld.
     */
    
    
    public Level2()
    {    
        super(WORLD_WIDTH, WORLD_HEIGHT, CELL_SIZE, false);
        prepareWorld();
        addObject(new Portal2(), 400, 87);
        
        SoundManager sound = new SoundManager();
        sound.initBgm("Backsound.mp3",50);
        sound.playBgm();
        
        FontText title = new FontText("LEVEL 2", 48, Color.WHITE);
        addObject(title, getWidth() / 2, 30);
    }
    
    /**
     * Method untuk menyiapkan elemen awal di world.
     */
    private void prepareWorld()
    {
        // Atur background

        setLayeredBackground();
        // Tambahkan player di tengah bawah lembah
        Player player = new Player();
        addObject(player, WORLD_WIDTH / 35, 492);
        addObject(new Rumput_Gersang(), 23, 530);
        addObject(new Kubus_Kayu(), 55, 546);
        addObject(new Kubus_Kayu(), 87, 546);
        addObject(new Kubus_Kayu(), 71, 530);
        addObject(new Kubus_Kayu(), 55, 530);
        addObject(new Kubus_Besi(), 71, 546);
        addObject(new Kubus_Besi(), 55, 514);
        addObject(new Batu_Bata_Abu_Kecil(), 47, 553);
        addObject(new Batu_Bata_Abu_Kecil(), 61, 523);
        addObject(new Batu_Bata_Abu_Kecil(), 4, 502);
        addObject(new Rumput_Gersang(), 364, 552);
        addObject(new Rumput_Gersang(), 234, 552);
        addObject(new Spike(), 270, 546);
        addObject(new Spike(), 290, 546);
        addObject(new Spike(), 312, 546);
        addObject(new Spike(), 334, 546);
        addObject(new Apple(), 300, 458);
        addObject(new Kubus_Besi(), 203, 546);
        addObject(new Kubus_Besi(), 395, 546);
        addObject(new Balok_Kayu(), 440, 472);
        addObject(new Balok_Kayu(), 601, 364);
        addObject(new Balok_Kayu(), 713, 364);
        addObject(new Balok_Kayu_Besar(), 520, 420);
        addObject(new Kubus_Kayu(), 641, 272);
        addObject(new Apple(), 714, 344);
        addObject(new Spike(), 645, 546);
        addObject(new Spike(), 675, 546);
        addObject(new Balok_Kayu(), 477, 292);
        addObject(new Apple(), 772, 534);
        addObject(new Enemy(), 444, 268);
        addObject(new Balok_Kayu(), 429, 292);
        addObject(new Kubus_Kayu(), 372, 261);
        addObject(new Balok_Kayu(), 247, 261);
        addObject(new Apple(), 308, 183);
        addObject(new Apple(), 26, 263);
        addObject(new Batu_Bata_Abu(), 119, 280);
        addObject(new Batu_Bata_Abu(), 72, 280);
        addObject(new Batu_Bata_Abu(), 642, 260);
        addObject(new Batu_Bata_Abu(), 601, 376);
        addObject(new Batu_Bata_Abu(), 713, 376);
        addObject(new Batu_Bata_Abu_Kotak(), 24, 300);
        
        addObject(new Balok_Kayu(), 92, 170);
        addObject(new Balok_Kayu(), 183, 127);
        addObject(new Balok_Kayu(), 232, 127);
        addObject(new Balok_Kayu(), 280, 127);
        addObject(new Balok_Kayu(), 398, 127);
        addObject(new Kubus_Kayu(), 8, 223);
        addObject(new Apple(), 94, 150);
        addObject(new Enemy(), 251, 103);
        
        addObject(new Balok_Kayu(), 760, 8);
        addObject(new Balok_Kayu(), 40, 8);
        addObject(new Balok_Besi(), 712, 8);
        addObject(new Balok_Kayu(), 88, 8);
        addObject(new Balok_Kayu_Stand(), 792, 40);
        addObject(new Balok_Besi_Stand(), 8, 40);
        addObject(new Balok_Besi_Stand(), 792, 88);
        addObject(new Balok_Kayu_Stand(), 8, 88);
        addObject(new Kubus_Kayu(), 792, 8);
        addObject(new Kubus_Kayu(), 8, 8);
        addObject(new Kubus_Besi(), 776, 24);
        addObject(new Kubus_Besi(), 24, 24);
        addObject(new Balok_Kayu(), 744, 24);
        addObject(new Balok_Besi(), 56, 24);
        addObject(new Balok_Besi_Stand(), 776, 56);
        addObject(new Balok_Kayu_Stand(), 24, 56);
        
        addObject(new Bendera_Besar(), 739, 51);
        addObject(new Bendera_Besar(), 57, 51);
        addObject(new Bendera_Besar(), 22, 348);
        addObject(new Bendera_Kecil(), 602, 387);
        addObject(new Bendera_Kecil(), 712, 388);
        addObject(new Mineral_Oren(), 32, 308);
        addObject(new Mineral_Oren(), 94, 588);
        addObject(new Mineral_Oren(), 522, 428);
        addObject(new Mineral_Oren(), 692, 545);

        // Generate platform (tanah dasar + tebing kiri kanan)
        generatePlatforms();
    }
private void setLayeredBackground() {
        // Pastikan semua file ada di folder "Background/"
        String[] layerFiles = {
            "Background/Level2_01.png", // paling belakang
            "Background/Level2_02.png",
            "Background/Level2_03.png",
            "Background/Level2_04.png"  // paling depan
        };

        // Gunakan ukuran world sebagai dasar
        GreenfootImage finalBg = new GreenfootImage(WORLD_WIDTH, WORLD_HEIGHT);

        for (String file : layerFiles) {
            GreenfootImage layer = new GreenfootImage(file);
            
            // Sesuaikan ukuran layer agar cocok dengan ukuran world
            layer.scale(WORLD_WIDTH, WORLD_HEIGHT);
            
            // Gabungkan layer satu per satu (belakang ke depan)
            finalBg.drawImage(layer, 0, 0);
        }

        setBackground(finalBg);
    }
    /**
     * Membuat platform tanah penuh & tebing kiri–kanan berbentuk upside-down (piramid terbalik rendah).
     */
    private void generatePlatforms()
{
    Rumput_Gersang sample = new Rumput_Gersang();
    int tileWidth = sample.getImage().getWidth();
    int tileHeight = sample.getImage().getHeight();

    // 1️⃣ Tanah dasar penuh (lembah bawah)
    for (int x = 0; x < WORLD_WIDTH; x += tileWidth) {
        addObject(new Rumput_Gersang(), x + tileWidth / 2, WORLD_HEIGHT - tileHeight / 2);
    }
}
}