import greenfoot.*;

public class Restart extends Actor
{
    public Restart() {
        GreenfootImage img = new GreenfootImage("Button/Restart.png");
        img.scale(100, 100);
        setImage(img);
    }

    public void act() {
        if (Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown("enter")) {
            restartGame();
        }
    }

    private void restartGame() {
        Greenfoot.setWorld(new Level1());
        Greenfoot.start(); // pastikan simulasi berjalan kembali
        
    }
}
