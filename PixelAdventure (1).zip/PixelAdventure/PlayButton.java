import greenfoot.*;

public class PlayButton extends Actor
{
    public PlayButton() {
    GreenfootImage img = new GreenfootImage("Button/Play.png");
    img.scale(150, 150); // ubah ukuran lebar dan tinggi (pixel)
    setImage(img);
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level1()); // Ganti ke Level1
        }
    }
}
