import greenfoot.*;

public class Perisai extends Actor
{
    public Perisai() {
        GreenfootImage img = new GreenfootImage("Button/Perisai.png");
        img.scale(500, 500); 
        
        setImage(img);
    }
}
