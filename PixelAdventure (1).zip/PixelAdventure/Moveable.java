/**
 * Interface Moveable
 * Digunakan untuk objek yang bisa bergerak dalam game (misalnya Player, Enemy, dll).
 */
public interface Moveable {
    void moveLeft();
    void moveRight();
    void jump();
    void applyGravity();
}
