import greenfoot.*;

public class Title extends Actor
{
    public Title() {
        GreenfootImage img = new GreenfootImage("Button/Title.png");
        img.scale(300, 300); 
        setImage(img);
    }
}
