import greenfoot.*;
import java.util.HashMap;

/**
 * SoundManager - pengelola suara sederhana untuk Greenfoot.
 * - simpan file audio di folder "sounds/" project Greenfoot.
 * - panggil method static dari mana saja: SoundManager.playEffect(...), playWinSound(...), playGameOver(...), dsb.
 */
public class SoundManager {
    private static GreenfootSound bgm = null;
    private static GreenfootSound gameOverSound = null;
    private static GreenfootSound winSound = null;

    // cache efek agar tidak create berkali-kali
    private static HashMap<String, GreenfootSound> effects = new HashMap<String, GreenfootSound>();

    // default volumes
    private static int defaultBgmVolume = 70;
    private static int defaultEffectVolume = 90;

    private static boolean muted = false;
    private static int backupBgmVolume = defaultBgmVolume;
    private static int backupEffectVolume = defaultEffectVolume;

    // ---------- BGM ----------
    public static void initBgm(String filename, int volume) {
        if (bgm == null) {
            bgm = new GreenfootSound(filename);
        }
        defaultBgmVolume = clampVolume(volume);
        if (!muted && bgm != null) bgm.setVolume(defaultBgmVolume);
    }

    public static void playBgm() {
        if (muted) return;
        if (bgm != null && !bgm.isPlaying()) bgm.playLoop();
    }

    public static void pauseBgm() {
        if (bgm != null && bgm.isPlaying()) bgm.pause();
    }

    public static void stopBgm() {
        if (bgm != null) bgm.stop();
    }

    public static void setBgmVolume(int volume) {
        defaultBgmVolume = clampVolume(volume);
        if (bgm != null) bgm.setVolume(muted ? 0 : defaultBgmVolume);
    }

    // ---------- GAME OVER ----------
    public static void playGameOver(String filename, int volume) {
        // hentikan / pause bgm supaya gameover terdengar jelas
        stopBgm();

        if (gameOverSound == null) {
            gameOverSound = new GreenfootSound(filename);
        }
        gameOverSound.stop();
        gameOverSound.setVolume(clampVolume(volume));
        gameOverSound.play();
    }

    // ---------- WIN SOUND ----------
    /**
     * Putar suara win. Default: pause bgm sementara agar suara win jelas terdengar.
     * Jika ingin hanya overlay tanpa pause, gunakan playEffect(...)
     */
    public static void playWinSound(String filename, int volume) {
        if (bgm != null && bgm.isPlaying()) {
            bgm.pause();
        }

        if (winSound == null) {
            winSound = new GreenfootSound(filename);
        }
        winSound.stop();
        winSound.setVolume(clampVolume(volume));
        winSound.play();
    }

    // ---------- GENERIC EFFECT ----------
    /**
     * Play effect pendek (hit, coin, dll) tanpa menghentikan bgm.
     * Efek di-cache agar tidak membuat objek berulang.
     */
    public static void playEffect(String filename, int volume) {
        if (muted) return;

        GreenfootSound s = effects.get(filename);
        if (s == null) {
            s = new GreenfootSound(filename);
            effects.put(filename, s);
        }
        s.setVolume(clampVolume(volume));
        if (s.isPlaying()) s.stop();
        s.play();
    }

    // convenience alias untuk hit
    public static void playHitSound(String filename, int volume) {
        playEffect(filename, volume);
    }

    // ---------- EFFECT VOLUME ----------
    public static void setEffectVolume(int volume) {
        backupEffectVolume = clampVolume(volume);
        for (GreenfootSound s : effects.values()) {
            s.setVolume(muted ? 0 : backupEffectVolume);
        }
        if (gameOverSound != null) gameOverSound.setVolume(muted ? 0 : backupEffectVolume);
        if (winSound != null) winSound.setVolume(muted ? 0 : backupEffectVolume);
    }

    // ---------- MUTE ----------
    public static void toggleMute() {
        if (!muted) {
            // mute
            backupBgmVolume = (bgm != null) ? bgm.getVolume() : defaultBgmVolume;
            backupEffectVolume = defaultEffectVolume;
            if (bgm != null) bgm.setVolume(0);
            for (GreenfootSound s : effects.values()) s.setVolume(0);
            if (gameOverSound != null) gameOverSound.setVolume(0);
            if (winSound != null) winSound.setVolume(0);
            muted = true;
        } else {
            // unmute
            if (bgm != null) bgm.setVolume(backupBgmVolume);
            for (GreenfootSound s : effects.values()) s.setVolume(backupEffectVolume);
            if (gameOverSound != null) gameOverSound.setVolume(backupEffectVolume);
            if (winSound != null) winSound.setVolume(backupEffectVolume);
            muted = false;
        }
    }

    public static boolean isMuted() {
        return muted;
    }

    // ---------- helper ----------
    private static int clampVolume(int v) {
        if (v < 0) return 0;
        if (v > 100) return 100;
        return v;
    }
    
    // Preload/caching effect agar tidak delay saat pertama kali dipanggil
public static void preloadEffect(String filename, int volume) {
    // jika sudah ada di cache, update volume saja
    GreenfootSound s = effects.get(filename);
    if (s == null) {
        s = new GreenfootSound(filename);
        effects.put(filename, s);
    }
    s.setVolume(clampVolume(volume));
    // jangan play di sini (hanya buat & set volume), tapi jika mau memaksa decode:
    // s.play(); s.stop(); // <-- opsional: memaksa decode sekarang (bisa membantu di beberapa JVM)
}
}
