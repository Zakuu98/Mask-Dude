import greenfoot.*;

/**
 * Kelas Enemy (Angry Pig)
 * Musuh berjalan bolak-balik di sekitar posisi awal.
 * Jarak gerak otomatis berdasarkan titik spawn (addObject).
 */
public class Enemy extends Actor {

    // ====== ANIMASI ======
    private GreenfootImage[] walkRight;
    private GreenfootImage[] walkLeft;
    private int frameIndex = 0;
    private int frameDelay = 5;
    private int frameCounter = 0;

    // ====== GERAKAN ======
    private int speed = 1; // kecepatan jalan (lebih lambat = lebih halus)
    private boolean movingRight = true;

    // Batas gerak kiri–kanan
    private int leftLimit;
    private int rightLimit;
    private int patrolRange = 30; // jarak maksimal ke kiri/kanan dari posisi awal

    private boolean initialized = false;

    // ====== KONSTRUKTOR ======
    public Enemy() {
        loadAnimation();
        setImage(walkRight[0]);
    }

    // ====== LOOP AKSI ======
    public void act() {
        if (!initialized && getWorld() != null) {
            // Simpan posisi awal saat pertama kali muncul
            int startX = getX();
            leftLimit = startX - patrolRange;
            rightLimit = startX + patrolRange;
            initialized = true;
        }

        if (initialized) {
            moveEnemy();
            animateWalk();
        }
    }

    // ============================================================== 
    // == GERAK =====================================================
    // ============================================================== 
    private void moveEnemy() {
        if (movingRight) {
            setLocation(getX() + speed, getY());
            if (getX() >= rightLimit) {
                movingRight = false;
            }
        } else {
            setLocation(getX() - speed, getY());
            if (getX() <= leftLimit) {
                movingRight = true;
            }
        }
    }

    // ============================================================== 
    // == ANIMASI =================================================== 
    // ============================================================== 
    private void animateWalk() {
        frameCounter++;
        if (frameCounter < frameDelay) return;
        frameCounter = 0;

        frameIndex = (frameIndex + 1) % walkRight.length;
        setImage(movingRight ? walkRight[frameIndex] : walkLeft[frameIndex]);
    }

    // ============================================================== 
    // == MUAT ASSET ================================================ 
    // ============================================================== 
    private void loadAnimation() {
        final int frameCount = 16;
        walkRight = new GreenfootImage[frameCount];
        walkLeft = new GreenfootImage[frameCount];

        for (int i = 0; i < frameCount; i++) {
            String idx = String.format("%02d", i);
            GreenfootImage img = new GreenfootImage("Level1/Enemy/AngryPig/" + idx + "_Walk (36x30).png");
            walkRight[i] = img;

            GreenfootImage mirrored = new GreenfootImage(img);
            mirrored.mirrorHorizontally();
            walkLeft[i] = mirrored;
        }
    }
}
