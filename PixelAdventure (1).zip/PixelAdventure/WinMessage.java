import greenfoot.*;

public class WinMessage extends Actor
{
    public WinMessage() {
    GreenfootImage img = new GreenfootImage("Button/Win.png");
    
    setImage(img);
    }
}
