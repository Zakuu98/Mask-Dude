import greenfoot.*;

public class GameOver extends Actor
{
    public GameOver() {
        GreenfootImage img = new GreenfootImage("Button/Game_Over.png");
        img.scale(300, 300); 
        setImage(img);
    }
}
