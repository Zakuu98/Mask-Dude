import greenfoot.*;

public class PreviousButton extends Actor
{
    public PreviousButton() {
    GreenfootImage img = new GreenfootImage("Button/Back.png");
    img.scale(50, 50); // ubah ukuran lebar dan tinggi (pixel)
    setImage(img);
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new MainMenu()); // Ganti ke mainmenu
        }
    }
}
