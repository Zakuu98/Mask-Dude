import greenfoot.*;

public class BoardInfo extends Actor
{
    public BoardInfo() {
        GreenfootImage img = new GreenfootImage("Button/BoardInfo.png");
        img.scale(500, 500); 
        
        setImage(img);
    }
}
