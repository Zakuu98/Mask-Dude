import greenfoot.*;

/**
 * Kelas Player dengan animasi, gravitasi, dan deteksi Game Over / Win.
 * Menambahkan animasi Hit ketika terkena Enemy atau Spike.
 */
public class Player extends Actor
{
    // ======== Variabel animasi ========
    private GreenfootImage[] idleFrames;
    private GreenfootImage[] runFrames;
    private GreenfootImage jumpFrame;
    private GreenfootImage[] hitFrames;

    private int animationIndex = 0;
    private int animationDelay = 5;
    private int animationCounter = 0;
    private String currentAnimation = "idle";
    private boolean facingRight = true;

    // ======== Fisika dan gerakan ========
    private double velocityY = 0;
    private double gravity = 0.6;
    private int jumpStrength = -10;
    private int moveSpeed = 3;
    private boolean onGround = false;

    // ======== Koleksi & Status ========
    public int applesCollected = 0;
    private boolean isGameOver = false;
    private boolean isWin = false;
    private boolean isHit = false;  // status animasi hit
    
    

    public Player()
    {
        loadAnimations();
        setImage(idleFrames[0]);
    }

    public void act()
    {
        if (isGameOver || isWin) return;
        if (getWorld() == null) return;

        // Jika sedang animasi hit, hanya jalankan animasi & tunggu selesai
        if (isHit)
        {
            playHitAnimation();
            return;
        }

        applyGravity();
        handleInput();
        checkPlatformCollision();
        checkAppleCollision();
        checkDangerCollision();
        checkTrophyCollision();
        checkWorldBounds();
        animate();
    }

    private void handleInput()
    {
        boolean moving = false;

        if (Greenfoot.isKeyDown("a"))
        {
            setLocation(getX() - moveSpeed, getY());
            if (isTouching(RumputHijauu.class)) setLocation(getX() + moveSpeed, getY());
            if (facingRight) facingRight = false;
            currentAnimation = "run";
            moving = true;
        }

        if (Greenfoot.isKeyDown("d"))
        {
            setLocation(getX() + moveSpeed, getY());
            if (isTouching(RumputHijauu.class)) setLocation(getX() - moveSpeed, getY());
            if (!facingRight) facingRight = true;
            currentAnimation = "run";
            moving = true;
        }

        if (Greenfoot.isKeyDown("space") && onGround)
        {
            velocityY = jumpStrength;
            onGround = false;
            currentAnimation = "jump";
        }

        if (!moving && onGround)
        {
            currentAnimation = "idle";
        }
    }

    private void applyGravity()
    {
        velocityY += gravity;
        int moveY = (int)Math.round(velocityY);
        int direction = (moveY > 0) ? 1 : -1;

        for (int i = 0; i < Math.abs(moveY); i++)
        {
            setLocation(getX(), getY() + direction);
            if (isTouching(Platform.class))
            {
                if (direction > 0)
                {
                    setLocation(getX(), getY() - 1);
                    velocityY = 0;
                    onGround = true;
                }
                else
                {
                    setLocation(getX(), getY() + 1);
                    velocityY = 0;
                }
                return;
            }
        }

        onGround = false;
    }

    private void checkPlatformCollision()
    {
        int halfWidth = getImage().getWidth() / 2;
        int halfHeight = getImage().getHeight() / 2;

        Actor platformBelowLeft = getOneObjectAtOffset(-halfWidth + 2, halfHeight, Platform.class);
        Actor platformBelowRight = getOneObjectAtOffset(halfWidth - 2, halfHeight, Platform.class);

        if ((platformBelowLeft != null || platformBelowRight != null) && velocityY >= 0)
        {
            Actor platformBelow = (platformBelowLeft != null) ? platformBelowLeft : platformBelowRight;
            int platformTop = platformBelow.getY() - platformBelow.getImage().getHeight() / 2;
            setLocation(getX(), platformTop - halfHeight);
            velocityY = 0;
            onGround = true;
        }
        else
        {
            onGround = false;
        }

        Actor platformAbove = getOneObjectAtOffset(0, -halfHeight, Platform.class);
        if (platformAbove != null && velocityY < 0)
        {
            int platformBottom = platformAbove.getY() + platformAbove.getImage().getHeight() / 2;
            setLocation(getX(), platformBottom + halfHeight + 1);
            velocityY = 0;
        }

        Actor platformLeft = getOneObjectAtOffset(-halfWidth, 0, Platform.class);
        Actor platformRight = getOneObjectAtOffset(halfWidth, 0, Platform.class);

        if (platformLeft != null)
        {
            int platformRightEdge = platformLeft.getX() + platformLeft.getImage().getWidth() / 2;
            setLocation(platformRightEdge + halfWidth + 1, getY());
        }
        else if (platformRight != null)
        {
            int platformLeftEdge = platformRight.getX() - platformRight.getImage().getWidth() / 2;
            setLocation(platformLeftEdge - halfWidth - 1, getY());
        }
    }

    private void checkWorldBounds()
    {
        World world = getWorld();
        if (world == null) return;

        int x = getX();
        int y = getY();
        int halfWidth = getImage().getWidth() / 2;

        int leftBound = halfWidth;
        int rightBound = Level1.WORLD_WIDTH - halfWidth;

        if (x < leftBound) setLocation(leftBound, y);
        else if (x > rightBound) setLocation(rightBound, y);
    }

    private void checkAppleCollision()
    {
        Apple apple = (Apple)getOneIntersectingObject(Apple.class);
        if (apple != null)
        {
            SoundManager.playEffect("applecollected.mp3", 50);
            apple.collect();
            applesCollected++;
        }
    }

    public int getApplesCollected()
    {
        return applesCollected;
    }

    private void checkDangerCollision()
    {
        if (isTouching(Enemy.class) || isTouching(Spike.class))
        {
            triggerHitAnimation();  // Panggil animasi hit sebelum game over
        }
    }

    private void checkTrophyCollision()
{
    Trophy trophy = (Trophy)getOneIntersectingObject(Trophy.class);
    if (trophy != null && !isWin)
    {
        isWin = true;
        World world = getWorld();
        if (world == null) return;

        // mainkan suara win (letakkan file you_win.mp3 di folder sounds/)
        SoundManager.playWinSound("win.wav", 90);

        world.removeObject(trophy);
        world.addObject(new WinMessage(), 394, 196);
        world.addObject(new ButtonMenu(), 397, 344);
    }
}


    // === Animasi HIT ===
    private void triggerHitAnimation()
    {
        if (isHit || isGameOver) return; // Hindari double trigger
        SoundManager.playHitSound("hit.mp3", 60);
        isHit = true;
        animationIndex = 0;
        currentAnimation = "hit";
    }

    private void playHitAnimation()
    {
        animationCounter++;
        if (animationCounter < animationDelay) return;
        animationCounter = 0;

        if (animationIndex < hitFrames.length)
        {
            GreenfootImage frame = new GreenfootImage(hitFrames[animationIndex]);
            if (!facingRight) frame.mirrorHorizontally();
            setImage(frame);
            animationIndex++;
        }
        else
        {
            // Setelah animasi hit selesai → Game Over
            isHit = false;
            gameOver();
        }
    }

    private void gameOver()
    {
        if (isGameOver || isWin) return;
        isGameOver = true;

        World world = getWorld();
        if (world == null) return;
        
        //backsound gameover
        SoundManager sound = new SoundManager();
        sound.playGameOver("gameover.mp3",50);
        
        GreenfootImage bg = new GreenfootImage(world.getBackground());
        GreenfootImage overlay = new GreenfootImage(world.getWidth(), world.getHeight());
        overlay.setColor(new Color(0, 0, 0, 150));
        overlay.fill();
        bg.drawImage(overlay, 0, 0);
        world.setBackground(bg);

        world.addObject(new GameOver(), world.getWidth() / 2, world.getHeight() / 2 - 50);
        world.addObject(new Restart(), world.getWidth() / 2, world.getHeight() / 2 + 80);
    }

    private void animate()
    {
        animationCounter++;
        if (animationCounter < animationDelay) return;
        animationCounter = 0;
        animationIndex++;

        GreenfootImage[] frames = null;

        switch (currentAnimation)
        {
            case "run":
                frames = runFrames;
                break;
            case "jump":
                setImage(jumpFrame);
                if (!facingRight) getImage().mirrorHorizontally();
                return;
            default:
                frames = idleFrames;
                break;
        }

        if (frames != null && frames.length > 0)
        {
            if (animationIndex >= frames.length) animationIndex = 0;
            GreenfootImage frame = new GreenfootImage(frames[animationIndex]);
            if (!facingRight) frame.mirrorHorizontally();
            setImage(frame);
        }
    }

    private void loadAnimations()
    {
        idleFrames = new GreenfootImage[11];
        for (int i = 0; i < 11; i++)
        {
            idleFrames[i] = new GreenfootImage("Level1/MainCharacters/MaskDude/Idle/Idle_frame_" + i + ".png");
        }

        runFrames = new GreenfootImage[12];
        for (int i = 0; i < 12; i++)
        {
            runFrames[i] = new GreenfootImage("Level1/MainCharacters/MaskDude/Run/Run_frame_" + i + ".png");
        }

        jumpFrame = new GreenfootImage("Level1/MainCharacters/MaskDude/Jump/Jump (32x32).png");

        // Animasi HIT (7 frame)
        hitFrames = new GreenfootImage[7];
        for (int i = 0; i < 7; i++)
        {
            hitFrames[i] = new GreenfootImage("Level1/MainCharacters/MaskDude/Hit/Hit_frame_" + i + ".png");
        }
    }
}
