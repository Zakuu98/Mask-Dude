import greenfoot.*;

/**
 * Kelas MainMenu — menampilkan background berlapis dan menambahkan objek.
 */
public class MainMenu extends World {
    public static final int WORLD_WIDTH = 800;
    public static final int WORLD_HEIGHT = 600;
    public static final int CELL_SIZE = 1;
    
    
    private boolean gameOverShown = false;
    
    //private GreenfootSound bgm;

    public MainMenu() {
        super(WORLD_WIDTH, WORLD_HEIGHT, CELL_SIZE, false);
        setLayeredBackground();
        prepareWorld();
        //addObject(new Portal(), 782, 231);
        //bgm = new GreenfootSound("Backsound.mp3");
        //bgm.setVolume(30);   // 0 - 100
        //bgm.playLoop();      // play terus menerus. gunakan play() untuk sekali
        SoundManager sound = new SoundManager();
        sound.initBgm("MenuMusic.mp3",50);
        sound.playBgm();
        
        //FontText title = new FontText("LEVEL 1", 48, Color.WHITE);
        //addObject(title, getWidth() / 2, 30);
    }

    /**
     * Menyusun background menjadi beberapa lapisan: 01 (paling belakang) → 04 (paling depan)
     */
    private void setLayeredBackground() {
        // Pastikan semua file ada di folder "Background/"
        String[] layerFiles = {
            "Background/01.png", // paling belakang
            "Background/02.png",
            "Background/03.png",
            "Background/04.png"  // paling depan
        };

        // Gunakan ukuran world sebagai dasar
        GreenfootImage finalBg = new GreenfootImage(WORLD_WIDTH, WORLD_HEIGHT);

        for (String file : layerFiles) {
            GreenfootImage layer = new GreenfootImage(file);
            
            // Sesuaikan ukuran layer agar cocok dengan ukuran world
            layer.scale(WORLD_WIDTH, WORLD_HEIGHT);
            
            // Gabungkan layer satu per satu (belakang ke depan)
            finalBg.drawImage(layer, 0, 0);
        }

        setBackground(finalBg);
    }

    /**
     * Menambahkan objek dalam world.
     */
    private void prepareWorld() {
        addObject(new Perisai(), getWidth() / 2, getHeight() / 2);
        addObject(new Title(), 400, 131);
        addObject(new PlayButton(), 400, 432);
        addObject(new ButtonInfo(), 516, 430);
    
        
        
        

        

        addObject(new Balok_Kayu(), 760, 8);
        addObject(new Balok_Kayu(), 40, 8);
        addObject(new Balok_Kayu(), 712, 8);
        addObject(new Balok_Kayu(), 88, 8);
        addObject(new Balok_Kayu_Stand(), 792, 40);
        addObject(new Balok_Kayu_Stand(), 8, 40);
        addObject(new Balok_Kayu_Stand(), 792, 88);
        addObject(new Balok_Kayu_Stand(), 8, 88);
        addObject(new Kubus_Kayu(), 792, 8);
        addObject(new Kubus_Kayu(), 8, 8);
        addObject(new Kubus_Kayu(), 776, 24);
        addObject(new Kubus_Kayu(), 24, 24);
        addObject(new Balok_Kayu(), 744, 24);
        addObject(new Balok_Kayu(), 56, 24);
        addObject(new Balok_Kayu_Stand(), 776, 56);
        addObject(new Balok_Kayu_Stand(), 24, 56);
        
        

        generatePlatforms();
    }

    private void generatePlatforms() {
        RumputHijauu sample = new RumputHijauu();
        int tileWidth = sample.getImage().getWidth();
        int tileHeight = sample.getImage().getHeight();

        for (int x = 0; x < WORLD_WIDTH; x += tileWidth) {
            addObject(new RumputHijauu(), x + tileWidth / 2, WORLD_HEIGHT - tileHeight / 2);
        }

    
    }
    
     public void act()
    {
        // Cek apakah GameOver sudah muncul
        if (!getObjects(GameOver.class).isEmpty()) {
            gameOverShown = true;
        }

        // Jika Enter ditekan saat GameOver muncul, restart game
        if (gameOverShown && Greenfoot.isKeyDown("enter")) {
            Greenfoot.setWorld(new MainMenu());
        }
    }
}
