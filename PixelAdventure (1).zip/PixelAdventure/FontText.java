import greenfoot.*;  

/**
 * Kelas FontText untuk menampilkan teks di tengah layar.
 */
public class FontText extends Actor  
{
    public FontText(String text, int fontSize, Color color) {
        // buat image teks
        GreenfootImage img = new GreenfootImage(text, fontSize, color, new Color(0,0,0,0));
        setImage(img);
    }
}
