import greenfoot.*;

public class Spike extends Actor
{
    public Spike()
    {
        setImage("Level1/Traps/Spike/Idle.png"); // Ganti sesuai nama file kamu
    }

    public void act()
    {
        checkCollision();
    }

    private void checkCollision()
    {
        Actor player = getOneIntersectingObject(Player.class);
        if (player != null)
        {
           // ((Player)player).hitBySpike();
        }
    }
    
    
}
