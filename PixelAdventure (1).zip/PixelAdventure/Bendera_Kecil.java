import greenfoot.*;

/**
 * Kelas Platform
 * ---------------------
 * Digunakan sebagai pijakan (lantai, balok, batu, kayu, dll.)
 * untuk Player atau objek lain di game platformer.
 *
 * Aset yang didukung:
 *  - Bendera_Kecil.png
 *  - Batu_Bata_Abu_Besar.png
 *  - Batu_Bata_Abu_Tepi.png
 *  - Kubus_Kayu.png
 *  - Pijakan_Kayu.png
 *  - TanahRumputHijau.png
 *  - Tanah_Rumput_Hijau_Kecil.png
 */
public class Bendera_Kecil extends Platform
{
    //private String type; // jenis platform (misal: "tanah", "batu", "kayu")
    private GreenfootImage image;

    /**
     * Konstruktor: buat platform berdasarkan nama aset.
     * Contoh:
     *   new Platform("TanahRumputHijau");
     */
    public Bendera_Kecil() {
        //this.type = type;
        loadImage("Level1/Terrain/Bendera_Kecil.png");
    }

    /**
     * Muat gambar sesuai jenis platform.
     */
    private void loadImage(String type) {
        String fileName = "Level1/Terrain/Bendera_Kecil.png";

        image = new GreenfootImage(fileName);
        setImage(image);
    }

    public void act() {
        // Platform tidak perlu logika gerak (diam saja)
        // Namun bisa diperluas nanti jika ingin platform bergerak.
    }
}
